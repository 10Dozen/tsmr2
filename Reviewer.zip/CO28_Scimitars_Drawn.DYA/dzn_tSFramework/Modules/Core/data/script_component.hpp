#include "..\..\script_macro.hpp"

#define COMPONENT core

#define DEFAULT_ORBAT_ORDERING ["RED","BLUE"]

#define LEGACY_MODULES \
    "CCP", \
    "FARP", \
    "ArtillerySupport", \
    "Interactives", \
    "ACEActions", \
    "EditorUnitBehavior", \
    "tSAdminTools", \
    "Conversations"
