#include "..\..\script_macro.hpp"


#define COMPONENT MissionDefaults

#define PHONETIC_ABC_WILDCARD "$"
#define NUMERIC_WILDCARD "#"
