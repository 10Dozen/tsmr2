class dzn_Dynamic_Dialog
{
    idd = 133798;
    movingEnable = false;
    class controls {};
};

class dzn_Dynamic_Dialog_Advanced
{
    idd = 134800;
    movingEnable = false;
    class controls {};
};

class dzn_Dynamic_Dialog_Advanced_v2
{
    idd = 134801;
    movingEnable = true;
    class controls {};
};

class RscTitles
{
    class dzn_Dynamic_Message
    {
        idd = 133799;
        movingEnable = 0;
        duration = 60000;
        onLoad = "_this call dzn_fnc_dynamicMessage_onLoad";
        class controls {};
    };
};
