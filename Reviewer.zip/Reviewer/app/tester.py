from .enums import Component, PageTitle, RawContentLanguage
from .entities import PageReviewHandler, PageStatus, PageData, Severity, TestResult, DataReader
from .mission_sqm_reader import MissionSqmReader

import re

def meta(id: str, name: str, severity: Severity, message=None):
    def decorator(func):
        def wrapper(*args, **kwargs):
            result: TestResult = func(*args, **kwargs)
            result.name = f"{id}.{name}"
            result.severity = severity
            if message:
                result.message = f"{message}.{result.message}"
            return result
        
        return wrapper
    return decorator

def tests(component: Component):
    def decorator(func):
        def wrapper(*args, **kwargs):
            result = func(*args, **kwargs)
            result.relates_to = component
            return result
        return wrapper
    return decorator



class Tester(PageReviewHandler):
    TITLE = PageTitle.Tests
    TESTS_PREFIX = 'test'

    def __init__(self, path: str):
        self.path = path
        self.components = {}
        self.results = None 
        self.results_raw = {}
    
    def register_component(self, name: Component, component: DataReader):
        self.components[name] = component
    
    def register_components(self, components: dict[Component, DataReader]):
        for name, component in components.items():
            self.register_component(name, component)

    def get_component(self, name: Component, reader: bool = True) -> DataReader:
        comp = self.components[name]
        return comp.reader if reader else comp

    def get_page_data(self):
        page = super().get_page_data()

        for result in self.results_raw:
            page.add_info(
                result.name,
                str(result)
            )
        return page

    def run_tests(self):
        r = [
            getattr(self,x)() 
            for x in dir(self) 
            if x.startswith(self.TESTS_PREFIX)
        ]
        # print(r)
        self.results_raw : list[TestResult] = r

    # ----
    # Tests
    # ----

    @tests(Component.Mission)
    @meta("SQM-001", "Имя превью картинки == overview.jpg", Severity.ERROR)
    def test_sqm001(self):
        sqm: MissionSqmReader = self.get_component(Component.Mission)
        
        return TestResult(
            is_success=sqm.overview_picture == 'overview.jpg',
            extra_data=sqm.overview_picture
        )

    @tests(Component.Mission)
    @meta("SQM-002", "Имя миссии соответсвует шаблону COXX Name (Version)", Severity.WARNING)
    def test_sqm002(self):
        sqm: MissionSqmReader = self.get_component(Component.Mission)
        title = sqm.title
        title_regex = r'^CO[0-9]+\s.+$\s\(.*\)$'
        is_match = re.match(title_regex, title, re.IGNORECASE)

        return TestResult(
            is_success=True if is_match else False,
            extra_data=title
        )

