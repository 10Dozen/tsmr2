from .mission_sqm_handler import MissionSqmHandler
from .tSFHandlers.tsf_reader import tSFrameworkSettingsReader
from .tSFHandlers.tsf_briefing_handler import tSFBriefingHandler
from .tSFHandlers.tsf_intro_text_handler import tSFIntroTextHandler
from .tSFHandlers.tsf_mission_conditions_handler import tSFMissionConditionsHandler
from .report_generator import ReportGenerator
from .enums import tSFModules

class Reviewer:
    def __init__(self, path):
        self.path = path
        self.mission_sqm = None
        self.tsf_settings = None
        self.tsf_briefing = None
        self.tsf_intro_text = None
        self.tsf_mission_conditions = None
        self.reporter = None

    def review(self):
        self.mission_sqm = MissionSqmHandler(self.path)
        self.tsf_settings = tSFrameworkSettingsReader(self.path)

        if self.tsf_settings.is_module_active(tSFModules.Briefing):
            self.tsf_briefing = tSFBriefingHandler(self.path)
        
        if self.tsf_settings.is_module_active(tSFModules.IntroText):
            self.tsf_intro_text = tSFIntroTextHandler(self.path)
        
        if self.tsf_settings.is_module_active(tSFModules.MissionConditions):
            self.tsf_mission_conditions = tSFMissionConditionsHandler(self.path)

        self.generate_report()

    def generate_report(self):
        """Creates report from the read data"""
        report_data = self.prepare_report_data()

        self.reporter = ReportGenerator(
            mission_name=self.mission_sqm.mission_filename,
            mission_creation_date=self.mission_sqm.creation_date
        )
        self.reporter.create_report(
            report_content=report_data,
            overview_img_path=self.mission_sqm.overview_img_src
        )

    def prepare_report_data(self):
        """Formats report data file"""
        report_data = {
            "filename": self.mission_sqm.mission_filename,
            "creationData": self.mission_sqm.creation_date,
            "pages": []
        }

        # Mission file page
        for handler in [
            self.mission_sqm,
            self.tsf_briefing,
            self.tsf_intro_text,
            self.tsf_mission_conditions
        ]:
            report_data['pages'].append(handler.get_page_data().export())

        return report_data

