
import os
import yaml


class tSFModuleReader:
    FRAMEWORK_DIR = 'dzn_tSFramework'
    MODULES_DIR = 'Modules'
    MODULE = ''
    SETTINGS_FILE = 'Settings.yaml'

    def __init__(self, path):
        self.path = os.path.join(path, self.FRAMEWORK_DIR,
                                 self.MODULES_DIR, self.MODULE)
        self.settings = None
        self.settings_yaml = None
        self._read_settings()

    def _get_settings_file(self):
        return os.path.join(self.path, self.SETTINGS_FILE)

    def _read_settings(self):
        settings_file = self._get_settings_file()

        with open(settings_file, 'r', encoding='utf-8') as f:
            self.settings = f.readlines()

        with open(settings_file, 'r', encoding='utf-8') as f:
            self.settings_yaml = yaml.safe_load(f)


class tSFrameworkSettingsReader(tSFModuleReader):
    MODULES_DIR = ''
    def __init__(self, path,):
        super().__init__(path)

    def is_module_active(self, module_name):
        return self.settings_yaml.get(module_name)

