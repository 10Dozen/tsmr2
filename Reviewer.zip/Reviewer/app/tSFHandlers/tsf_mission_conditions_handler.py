
from ..enums import PageStatus, PageTitle, RawContentLanguage, tSFModules
from ..data_entities import PageReviewHandler, PageData
from .tsf_reader import tSFModuleReader


class tSFMissionConditionsReader(tSFModuleReader):
    MODULE = tSFModules.MissionConditions

class tSFMissionConditionsHandler(PageReviewHandler):
    TITLE = PageTitle.tSF_MissionConditions

    def __init__(self, path):
        self.reader = tSFMissionConditionsReader(path)

    def get_page_data(self):
        page_data: PageData = super().get_page_data()
        conditions = self.reader.settings_yaml.get('Conditions')

        for idx, c in enumerate(conditions):
            page_data.add_info(f"Концовка {idx}", c.get("name"))
            page_data.add_info("Описание", c.get("description", "<не указан>"))
            page_data.add_info("Таймаут", c.get("timeout", "<по умолчанию>"))

        page_data.add_raw_content(
            self.reader.SETTINGS_FILE,
            ''.join(self.reader.settings),
            RawContentLanguage.YAML
        )

        return page_data