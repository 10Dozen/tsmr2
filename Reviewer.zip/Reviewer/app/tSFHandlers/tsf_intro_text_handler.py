
from ..enums import PageStatus, PageTitle, RawContentLanguage
from ..data_entities import PageReviewHandler, PageData
from .tsf_reader import tSFModuleReader


class tSFIntroTextReader(tSFModuleReader):
    MODULE = 'IntroText'


class tSFIntroTextHandler(PageReviewHandler):
    TITLE = PageTitle.tSF_IntroText
    READER = ""
    VALIDATOR = ""

    def __init__(self, path):
        self.reader = tSFIntroTextReader(path)

    def get_page_data(self):
        page_data: PageData = super().get_page_data()
        page_data.add_info("Дата", self.reader.settings_yaml.get("Date"))
        page_data.add_info("Локация", self.reader.settings_yaml.get("Location"))
        page_data.add_info("Операция", self.reader.settings_yaml.get("Operation"))

        page_data.add_raw_content(
            self.reader.SETTINGS_FILE,
            ''.join(self.reader.settings),
            RawContentLanguage.YAML
        )

        return page_data