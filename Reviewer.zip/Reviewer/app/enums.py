from enum import StrEnum, auto


class tSFModules(StrEnum):
    Briefing = 'Briefing'
    IntroText = 'IntroText'
    MissionConditions = 'MissionConditions'

    def __repr__(self):
        return self.value


class PageTitle(StrEnum):
    Mission = "Миссия"
    tSF_Briefing = f"tSF / {tSFModules.Briefing}"
    tSF_IntroText = f"tSF / {tSFModules.IntroText}"
    tSF_MissionConditions = f"tSF / {tSFModules.MissionConditions}"

    def __repr__(self):
        return f'"{self.value}"'


class PageStatus(StrEnum):
    OK = auto()
    DISABLED = auto()
    ERROR = auto()
    WARNING = auto()

    def __repr__(self):
        return f'"{self.value.upper()}"'


class InfoType(StrEnum):
    PLAIN = 'plain'
    MULTILINE = 'multiline'
    MISSION_TAGS = 'missionTags'

    def __repr__(self):
        return f'"{self.value}"'


class RawContentLanguage(StrEnum):    
    IMAGE = 'image'
    CPP = 'cpp'
    YAML = 'yaml'

    def __repr__(self):
        return f'"{self.value}"'