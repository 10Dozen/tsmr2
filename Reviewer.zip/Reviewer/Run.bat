py app.py 

pause