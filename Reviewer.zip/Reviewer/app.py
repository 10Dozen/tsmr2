from app.reviewer import Reviewer

import os
import sys
import shutil
import zipfile
import requests

"""
TODO:
    - Unzip and read mission data
    - Download mission form GitHub
        https://github.com/TacticalShift/mmo/blob/main/CO31_Operation_Eisenschild.VTF_Lybor.zip
        https://raw.githubusercontent.com/TacticalShift/mmo/main/CO31_Operation_Eisenschild.VTF_Lybor.zip
"""

def resolve_mission_path(path):
    if not path.startswith('https'):
        return path

    mission_filename_zip = path.rsplit('/', maxsplit=1)[-1]
    if path.startswith('https://github.com/TacticalShift/mmo/'):
        path = 'https://raw.githubusercontent.com/TacticalShift/mmo/main/' + mission_filename_zip
    
    shutil.rmtree("temp")
    os.mkdir("temp")
    r = requests.get(path)
    with open("temp_mission.zip", mode="wb") as f:
        f.write(r.content)
    zf = zipfile.ZipFile("temp_mission.zip")
    zf.extractall(path="temp")
    return os.path.join("temp", mission_filename_zip.rsplit('.', maxsplit=1)[0])


if __name__ == '__main__':
    print('┌-------------------------------------┐')
    print('|     tS Mission Reviewer v2.0.0      |')
    print('└-------------------------------------┘')
    print()

    #path = r'C:\Vaults\a3\tsmr\CO29_Space_Shield.ProvingGrounds_PMC'
    path = r'C:\Vaults\a3\tsmr\CO28_Scimitars_Drawn.DYA'
    #path = r'https://github.com/TacticalShift/mmo/blob/main/CO41_Operation_Kaiten_Part1.cup_chernarus_A3.zip'
    # while not os.path.exists(path):
    #     path = input('Enter path to reviewed mission:')

    path = resolve_mission_path(path)

    op_result = Reviewer(path).review()

    if path.startswith("temp"):
        shutil.rmtree("temp")
        
    sys.exit(op_result)

